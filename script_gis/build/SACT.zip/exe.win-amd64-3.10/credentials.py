#sars2 credentials
gis = {
    'username' : '', 
    'password' : '', 
}
